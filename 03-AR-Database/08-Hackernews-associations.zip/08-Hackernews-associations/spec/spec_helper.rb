require 'minitest/autorun'
require 'minitest/pride'